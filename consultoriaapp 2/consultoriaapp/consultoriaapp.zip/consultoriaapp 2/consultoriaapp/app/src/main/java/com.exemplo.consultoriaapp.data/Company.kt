package com.exemplo.consultoriaapp.data

data class Company(
    val id: Int,
    val name: String,
    val details: String
)