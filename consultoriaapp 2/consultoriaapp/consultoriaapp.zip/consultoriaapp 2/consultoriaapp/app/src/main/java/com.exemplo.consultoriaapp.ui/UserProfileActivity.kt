package com.exemplo.consultoriaapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.consultoriaapp.R

class UserProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)
    }
}