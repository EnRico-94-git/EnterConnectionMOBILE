package com.exemplo.consultoriaapp.data

class CompanyRepository {
}