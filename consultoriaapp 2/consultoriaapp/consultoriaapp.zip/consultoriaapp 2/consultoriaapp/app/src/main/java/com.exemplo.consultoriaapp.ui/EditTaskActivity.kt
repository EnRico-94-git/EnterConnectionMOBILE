package com.exemplo.consultoriaapp.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.consultoriaapp.R

class EditTaskActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task)

        // Captura os componentes de UI
        val editText = findViewById<EditText>(R.id.edit_company_name)
        val buttonSave = findViewById<Button>(R.id.button_save)

        // Definir ação para o botão de salvar
        buttonSave.setOnClickListener {
            // Obter o texto digitado no EditText
            val companyName = editText.text.toString()

            if (companyName.isNotEmpty()) {
                // Exibe uma mensagem de sucesso (pode ser substituída por uma lógica de salvar dados)
                Toast.makeText(this, "Empresa '$companyName' salva com sucesso!", Toast.LENGTH_SHORT).show()

                // Aqui você pode adicionar lógica de salvamento, como enviar os dados para uma API ou banco de dados
            } else {
                // Exibe um aviso se o campo estiver vazio
                Toast.makeText(this, "Por favor, insira o nome da empresa.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
